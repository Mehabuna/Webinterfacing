import os
from django.shortcuts import render
from os import listdir
from bs4 import UnicodeDammit
import re

# Create your views here.
def home_view(request):
	return render(request,'home.html',{})

def about_view(request):
	return render(request,'about.html',{})

def contact_view(request):
	return render(request,'contact.html',{})

def abs_summarize(request):
	path = './static/dataset/abs_summarize'
	lis=[folder for folder in listdir(path)]
	params={'List_of_dirs':lis, 'dataset': 'abs_summarize' }
	return render(request,'dataset.html', params)

def ext_summarize(request):
	path = './static/dataset/ext_summarize'
	lis=[folder for folder in listdir(path)]
	params={'List_of_dirs' :lis, 'dataset' :'ext_summarize'}
	return render(request,'dataset.html', params)

def squad_dataset(request):
	path = './static/dataset/squad_dataset'
	lis=[folder for folder in listdir(path)]
	params={'List_of_dirs' :lis, 'dataset' : 'squad_dataset'}
	return render(request,'dataset2.html', params)

def odqa_dataset(request):
	path = './static/dataset/odqa_dataset'
	lis=[folder for folder in listdir(path)]
	params={'List_of_dirs' :lis, 'dataset' : 'odqa_dataset'}
	return render(request,'dataset2.html', params)

def get_articles(request,dataset,folder_path):
	path = './static/dataset/'+dataset+'/'+folder_path+'/'
	if (dataset == "abs_summarize"):
		lis=[folder for folder in listdir(path)]
	elif(dataset == "ext_summarize"):
		lis=[folder.split('.')[0] for folder in listdir(path+"input")]
	else:
		return render(request,'error.html',{"error":"the dataset path is specified"})
	content = {
	'folder' : folder_path,
	'list_folders' : lis,
	'dataset' :dataset,
	}
	return render(request,'articles.html',content)

def get_contents(request,dataset,folder_path,article):
	path = './static/dataset/'+dataset+'/'+folder_path+'/'
	if (dataset=="abs_summarize"):
		lis=[folder for folder in listdir(path)]
	elif(dataset=="ext_summarize"):
		lis=[folder.split('.')[0] for folder in listdir(path+"input")]
	else:
		return render(request,'error.html',{"error":"the dataset path is specified"})
	
	org_article = sum_article=""

	if(dataset=="abs_summarize"):
		org_article = os.path.join(path,article)+"/article."+article+".txt"
		sum_article =  os.path.join(path,article)+"/article."+article+".summ.txt"
	elif(dataset=="ext_summarize"):
		org_article = path+"/input/"+article+".txt"
		sum_article = path+"/output/"+article+"_out.txt"
	else:
		return render(request,'error.html',{"error":"the dataset path is specified"})

	f=open(org_article,"r",encoding="utf-8")
	org_content=f.read()
	f.close()

	
	f=open(sum_article,"r",encoding="utf-8")
	sum_content=f.read()
	f.close()

	content={
		'article_id' : article,
		'article' : org_content,
		'summary' : sum_content,
		'folder'  : folder_path,
		'dataset' : dataset,
		'list_folders' : lis,
	}
	return render(request,'articles.html',content)

def get_articles2(request,dataset,folder_path):
	path = './static/dataset/'+dataset+'/'+folder_path+'/'
	if(dataset=="squad_dataset"):
		lis=[folder for folder in listdir(path)]
	elif(dataset=="odqa_dataset"):
		lis=[folder for folder in listdir(path)]
		org_article= os.path.join(path)+"/29751_29800"+"/29751_29800.labeled.txt"
		file = open("org_article", "r",encoding="utf-8")
		content = file.readlines()
		num=len(content)
		lis =[i for i in range(1,num+1)]
	else:
		return render(request,'error.html',{"error":"the dataset path is specified"})
	content = {
	'folder' : folder_path,
	'list_folders' : lis,
	'dataset' :dataset,
	}
	return render(request,'articles2.html',content)



def get_contents2(request,dataset,folder_path,article):

	path = './static/dataset/'+dataset+'/'+folder_path+'/'

	if(dataset=="squad_dataset"):
		lis=[folder for folder in listdir(path)]
	elif(dataset=="odqa_dataset"):
		org_article= os.path.join(path,article)+article+".labeled.txt"
		file = open("org_article", "r",encoding="utf-8")
		content = file.readlines()
		num=len(content)
		lis =[i for i in range(1,num+1)]
	else:
		return render(request,'error.html',{"error":"the dataset path is specified"})


	if(dataset=="squad_dataset"):
		org_article = os.path.join(path,article)+"/article."+article+".txt"
		sum_article =  os.path.join(path,article)+"/article."+article+".summ.txt"
	elif(dataset=="odqa_dataset"):
		org_file =  os.path.join(path,article)+".labeled.txt"
	else:
		return render(request,'error.html',{"error":"the dataset path is specified"})

	file = open("org_file", "r",encoding="utf-8")
	data= file.read()
	An = []
	Qu = []
	pattern=r'[A-Z]{3}'
	lab=re.findall(pattern,data)
	pattern=r'[@]{3}.*'
	Ans =re.findall(pattern,data)
	for ans in Ans:
    		Answer=ans
    		Answer=Answer.replace("@@@","")
    		An.append(Answer)
	pattern=r'].*?@@@'
	Que =re.findall(pattern,data)
	for que in Que:
    		Question=que
    		Question=Question.replace("@@@","")
    		Question=Question.replace("]","")
    		Qu.append(Question)

	content={
		'article_id' : article,
		'folder'  : folder_path,
		'dataset' : dataset,
		'list_folders' : lis,
		'Answer'    : An,
		'Question'  :Qu,
		'Label'     :lab,
	}
	return render(request,'articles2.html',content)